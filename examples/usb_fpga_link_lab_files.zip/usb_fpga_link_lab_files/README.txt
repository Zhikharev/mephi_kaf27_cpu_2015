CONTENTS:

--lab8_usb_fpgalink.pdf
Lab#9 document: it explains the steps to follow in order to install 
all you need to do this lab. All the applications
that you would need are included in this archive (listed below);
except the first one (Visual C++ Express 2010), which you should 
download and install on your own from the Internet.
Also, in general, you should download on your own directly each
of these software applications; in this way you get the latest version
for each. This is especially recommended for the main one: FPGALink.
Included here are some datasheets; it does not harm for you to
read them "diagonally"...

-- Visual C++ Express 2010
Download from: http://www.microsoft.com/visualstudio/en-us/products/2010-editions/express#Visual_Studio_2010_Express_Downloads

-- Microsoft Visual C++ 2010 Redistributable Package (x86)
vcredist_x86.exe

-- SDCC 2.9.0
sdcc-2.9.0-setup.exe

-- Console 2
Console-2.00b148-Beta_32bit.zip

-- Barebone Build Infrastructure of Chris McClelland. In this structure FPGALink 
library will be unpacked/copied (or compiled/installed if you decide to compile
it from scratch; it did not work at first trial in my case).
makestuff-win32-20111211.zip
-- FPGALink Library binaries
libfpgalink-20120621.tar.gz

-- FPGALink User Manual (VHDL Edition)
vhdl_paper.pdf

-- LibUSB-Win32
libusb-win32-bin-1.2.6.0.zip
-- Driver saved during LibUSB-Win32's run (as a backup copy)
Digilent_USB_Device.inf

-- Datasheet of CY7C68013A-56 USB Microcontroller High-Speed USB Peripheral Controller
CY7C68013A_CY7C68014A_CY7C68015A_CY7C68016A.pdf

-- USB3 specification
USB3.pdf

-- lab8_files_ISE
These are the files you need for the ISE WebPack project:
1. comm_fpga_fx2.vhdl
2. top_level.vhdl
3. top_level.ucf